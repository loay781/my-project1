# Flutter Form Assignment

مشروع Flutter تعليمي يطبّق أدوات الإدخال والتفاعل مع قواعد التحقق باستخدام `Form` و`GlobalKey<FormState>`.

## محتويات التطبيق

يحتوي التطبيق على شاشة واحدة تشمل `TextField` و`TextFormField` للبريد والهاتف والحقل المطلوب، و`Checkbox` للموافقة، و`Radio` للجنس، و`Switch` للإشعارات، و`Slider` للخبرة، و`RangeSlider` للعمر، و`DropdownButton` للمدينة، و`PopupMenuButton` للغة.

عند الضغط على زر **إرسال** يتم التحقق من جميع الحقول. إذا كانت البيانات صحيحة يظهر مربع حوار يحتوي على ملخص القيم المدخلة، وإذا كانت غير صحيحة تظهر رسالة الخطأ أسفل الحقل المرتبط بها. زر **إعادة تعيين** يمسح القيم ويرجع الإعدادات الافتراضية.

## المتطلبات

يحتاج تشغيل المشروع إلى تثبيت Flutter SDK وإعداد أحد الأجهزة الافتراضية أو توصيل هاتف فعلي.

## التشغيل محليًا

```bash
flutter pub get
flutter run
```

## رفع المشروع إلى GitHub

بعد فك ضغط المشروع، افتح الطرفية داخل مجلد المشروع ونفّذ الأوامر التالية:

```bash
git init
git add .
git commit -m "Initial Flutter form validation app"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```

استبدل `USERNAME/REPOSITORY` باسم المستخدم واسم المستودع في GitHub.

## الملف الرئيسي

الكود الأساسي موجود في:

```text
lib/main.dart
```
