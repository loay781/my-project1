import 'package:flutter/material.dart';

void main() {
  runApp(const InputValidationApp());
}

class InputValidationApp extends StatelessWidget {
  const InputValidationApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'واجب أدوات الإدخال',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
          filled: true,
        ),
      ),
      home: const InputFormPage(),
    );
  }
}

class InputFormPage extends StatefulWidget {
  const InputFormPage({super.key});

  @override
  State<InputFormPage> createState() => _InputFormPageState();
}

class _InputFormPageState extends State<InputFormPage> {
  final _formKey = GlobalKey<FormState>();
  final _ordinaryTextController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _requiredController = TextEditingController();

  bool _agreed = false;
  String? _gender;
  bool _notifications = false;
  double _experience = 5;
  RangeValues _ageRange = const RangeValues(18, 30);
  String? _city;
  String? _language;

  final List<String> _cities = ['صنعاء', 'عدن', 'تعز', 'الحديدة'];
  final List<String> _languages = ['العربية', 'الإنجليزية', 'الفرنسية'];

  @override
  void dispose() {
    _ordinaryTextController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _requiredController.dispose();
    super.dispose();
  }

  void _submitForm() {
    final isValid = _formKey.currentState?.validate() ?? false;
    if (!isValid) return;

    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('ملخص البيانات'),
        content: SingleChildScrollView(
          child: Text(
            'النص العادي: ${_ordinaryTextController.text}\n'
            'البريد الإلكتروني: ${_emailController.text}\n'
            'الهاتف: ${_phoneController.text}\n'
            'الحقل المطلوب: ${_requiredController.text}\n'
            'الموافقة: ${_agreed ? 'نعم' : 'لا'}\n'
            'الجنس: ${_gender ?? 'غير محدد'}\n'
            'الإشعارات: ${_notifications ? 'مفعّلة' : 'متوقفة'}\n'
            'الخبرة: ${_experience.toStringAsFixed(0)}\n'
            'العمر: ${_ageRange.start.toStringAsFixed(0)} - ${_ageRange.end.toStringAsFixed(0)}\n'
            'المدينة: ${_city ?? 'غير محددة'}\n'
            'اللغة: ${_language ?? 'غير محددة'}',
            textDirection: TextDirection.rtl,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إغلاق'),
          ),
        ],
      ),
    );
  }

  void _resetForm() {
    _formKey.currentState?.reset();
    _ordinaryTextController.clear();
    _emailController.clear();
    _phoneController.clear();
    _requiredController.clear();

    setState(() {
      _agreed = false;
      _gender = null;
      _notifications = false;
      _experience = 5;
      _ageRange = const RangeValues(18, 30);
      _city = null;
      _language = null;
    });
  }

  InputDecoration _decoration(String label) {
    return InputDecoration(labelText: label);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('أدوات الإدخال والتحقق'),
          centerTitle: true,
        ),
        body: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text(
                'نموذج تطبيق أدوات Flutter',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              const Text('املأ البيانات ثم اضغط على زر إرسال للتحقق من النموذج.'),
              const SizedBox(height: 20),

              TextField(
                controller: _ordinaryTextController,
                decoration: _decoration('1. نص عادي بدون تحقق'),
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: _decoration('2. البريد الإلكتروني'),
                validator: (value) =>
                    value!.contains('@') ? null : 'بريد غير صحيح',
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                maxLength: 10,
                decoration: _decoration('3. الهاتف - 10 أرقام'),
                validator: (value) =>
                    value!.length == 10 ? null : 'رقم غير صحيح',
              ),
              const SizedBox(height: 4),

              TextFormField(
                controller: _requiredController,
                decoration: _decoration('4. حقل مطلوب'),
                validator: (value) =>
                    value!.isEmpty ? 'مطلوب' : null,
              ),
              const SizedBox(height: 16),

              FormField<bool>(
                initialValue: _agreed,
                validator: (value) =>
                    value == true ? null : 'وافق على الشروط',
                builder: (field) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('5. أوافق على الشروط والأحكام'),
                      value: _agreed,
                      onChanged: (value) {
                        setState(() => _agreed = value ?? false);
                        field.didChange(value ?? false);
                      },
                    ),
                    if (field.hasError)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Text(
                          field.errorText!,
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.error,
                            fontSize: 12,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 12),

              FormField<String>(
                initialValue: _gender,
                validator: (value) =>
                    value != null ? null : 'اختر الجنس',
                builder: (field) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('6. الجنس', style: TextStyle(fontSize: 16)),
                    RadioListTile<String>(
                      title: const Text('ذكر'),
                      value: 'ذكر',
                      groupValue: _gender,
                      onChanged: (value) {
                        setState(() => _gender = value);
                        field.didChange(value);
                      },
                    ),
                    RadioListTile<String>(
                      title: const Text('أنثى'),
                      value: 'أنثى',
                      groupValue: _gender,
                      onChanged: (value) {
                        setState(() => _gender = value);
                        field.didChange(value);
                      },
                    ),
                    if (field.hasError)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Text(
                          field.errorText!,
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.error,
                            fontSize: 12,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 12),

              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('7. إشعارات التطبيق'),
                subtitle: Text(_notifications ? 'مفعّلة' : 'متوقفة'),
                value: _notifications,
                onChanged: (value) => setState(() => _notifications = value),
              ),
              const SizedBox(height: 12),

              FormField<double>(
                initialValue: _experience,
                validator: (value) => value != null &&
                        value >= 0 &&
                        value <= 10
                    ? null
                    : 'خارج النطاق',
                builder: (field) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('8. الخبرة: ${_experience.toStringAsFixed(0)}'),
                    Slider(
                      min: 0,
                      max: 10,
                      divisions: 10,
                      label: _experience.toStringAsFixed(0),
                      value: _experience,
                      onChanged: (value) {
                        setState(() => _experience = value);
                        field.didChange(value);
                      },
                    ),
                    if (field.hasError)
                      Text(field.errorText!,
                          style: TextStyle(
                              color: Theme.of(context).colorScheme.error)),
                  ],
                ),
              ),
              const SizedBox(height: 12),

              FormField<RangeValues>(
                initialValue: _ageRange,
                validator: (value) => value != null &&
                        value.start < value.end
                    ? null
                    : 'نطاق غير صحيح',
                builder: (field) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '9. العمر: ${_ageRange.start.toStringAsFixed(0)} - ${_ageRange.end.toStringAsFixed(0)}',
                    ),
                    RangeSlider(
                      min: 0,
                      max: 100,
                      divisions: 100,
                      values: _ageRange,
                      labels: RangeLabels(
                        _ageRange.start.toStringAsFixed(0),
                        _ageRange.end.toStringAsFixed(0),
                      ),
                      onChanged: (value) {
                        setState(() => _ageRange = value);
                        field.didChange(value);
                      },
                    ),
                    if (field.hasError)
                      Text(field.errorText!,
                          style: TextStyle(
                              color: Theme.of(context).colorScheme.error)),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              DropdownButtonFormField<String>(
                value: _city,
                decoration: _decoration('10. المدينة'),
                items: _cities
                    .map((city) => DropdownMenuItem(
                          value: city,
                          child: Text(city),
                        ))
                    .toList(),
                onChanged: (value) => setState(() => _city = value),
                validator: (value) =>
                    value != null ? null : 'اختر مدينة',
              ),
              const SizedBox(height: 16),

              FormField<String>(
                initialValue: _language,
                validator: (value) =>
                    value != null ? null : 'اختر لغة',
                builder: (field) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    InputDecorator(
                      decoration: _decoration('11. اللغة').copyWith(
                        errorText: field.hasError ? field.errorText : null,
                      ),
                      child: PopupMenuButton<String>(
                        initialValue: _language,
                        onSelected: (value) {
                          setState(() => _language = value);
                          field.didChange(value);
                        },
                        itemBuilder: (context) => _languages
                            .map((language) => PopupMenuItem<String>(
                                  value: language,
                                  child: Text(language),
                                ))
                            .toList(),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(_language ?? 'اختر لغة'),
                            const Icon(Icons.arrow_drop_down),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _submitForm,
                      icon: const Icon(Icons.send),
                      label: const Text('إرسال'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextButton.icon(
                      onPressed: _resetForm,
                      icon: const Icon(Icons.refresh),
                      label: const Text('إعادة تعيين'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
